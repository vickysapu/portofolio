<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Portofolio</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>
<body>
<div class="header">
    <ul>
        <li><a href="<?php echo e(route('login')); ?>"><i class="fa-solid fa-right-from-bracket"></i></a></li>
        <li><a href="#message"><i class="fa-solid fa-message"></i></a></li>
        <li><a href="#social-media-form"><i class="fa-solid fa-phone"></i></a></li>
        <li><a href="#skills"><i class="fa-solid fa-chart-simple"></i></a></li>
        <li><a href="#add-portofolio"><i class="fa-solid fa-suitcase"></i></a></li>
        <li><a href="#dashboard"><i class="fa-solid fa-house-user"></i></a></li>
    </ul>
</div>
<?php
    $dataProfile = \App\Models\Profile::all();
?>
<div class="container">
    <section class="dashboard" id="dashboard">
        <div class="profile-container">
            <?php $__currentLoopData = $dataProfile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="profile-header">
                <img src="../imgProfile/<?php echo e($profile->gambar); ?>" class="profile-pic">
                <h1><?php echo e($profile->nama_lengkap); ?></h1>
            </div>
                <form action="<?php echo e(route('update_profile')); ?>" method="POST" class="profile-form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" id="fullName" name="nama_lengkap" value="<?php echo e($profile->nama_lengkap); ?>" placeholder="Enter your full name">
                    </div>
                    <div class="form-group">
                        <input type="text" id="username" name="nama_panggilan" value="<?php echo e($profile->nama_panggilan); ?>" placeholder="Enter your username">
                    </div>
                    <div class="form-group">
                        <input type="text" id="password" name="password" value="<?php echo e($profile->password); ?>" placeholder="Enter your password">
                    </div>
                    <div class="form-group">
                        <input type="file" id="profilePhoto" name="gambar">
                    </div>
                    <button type="submit">Update</button>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
</div>


    <section class="add-portofolio" id="add-portofolio">
        <div class="container-add-portofolio">
            <h3>Tambah Portofolio Baru</h3>
            <form action="/submit-portofolio" method="POST">
                <div class="form-group">
                    <label for="nama-portofolio">Nama Portofolio</label>
                    <input type="text" id="nama-portofolio" name="nama_portofolio" placeholder="Masukkan nama portofolio" required>
                </div>

                <div class="form-group">
                    <label for="deskripsi">Deskripsi</label>
                    <textarea id="deskripsi" name="deskripsi" rows="4" placeholder="Masukkan deskripsi portofolio" required></textarea>
                </div>

                <div class="form-group">
                    <label for="link">Link</label>
                    <input type="url" id="link" name="link" placeholder="Masukkan link portofolio" required>
                </div>

                <div class="form-group">
                    <input type="submit" value="Tambah Portofolio">
                </div>
            </form>
        </div>
    </section>


    <section class="skills" id="skills">
        <div class="container-skill">
            <div class="container-item-skill">
                <h3>My Skills</h3>

                <div class="skill-bar">
                    <label for="php">Pemrograman PHP</label>
                    <div class="progress-bar">
                        <progress id="php" value="32" max="100"></progress>
                        <span>32%</span>
                    </div>
                </div>

                <div class="skill-bar">
                    <label for="laravel">Pemrograman LARAVEL</label>
                    <div class="progress-bar">
                        <progress id="laravel" value="50" max="100"></progress>
                        <span>50%</span>
                    </div>
                </div>

                <div class="skill-bar">
                    <label for="flutter">Pemrograman FLUTTER</label>
                    <div class="progress-bar">
                        <progress id="flutter" value="70" max="100"></progress>
                        <span>70%</span>
                    </div>
                </div>

                <button id="openModalBtn" class="open-modal-btn">Tambah Skill</button>
            </div>
        </div>
    </section>


    <section class="message-box" id="message">
        <div class="message">
            <h4>From: <span class="sender-name">John Doe</span></h4>
            <p class="email">Email: johndoe@example.com</p>
            <div class="message-content">
                <p>Hello, I wanted to reach out and ask for more information about your services. Looking forward to hearing from you!</p>
            </div>
        </div>
    </section>

    <section class="social-media-form" id="social-media-form">
        <h3>Ganti Akun Sosial Media</h3>
        <form action="/update-social-media" method="POST">
            <div class="form-group">
                <label for="facebook">Facebook</label>
                <input type="text" id="facebook" name="facebook" placeholder="Masukkan link Facebook">
            </div>

            <div class="form-group">
                <label for="whatsapp">WhatsApp</label>
                <input type="text" id="whatsapp" name="whatsapp" placeholder="Masukkan nomor WhatsApp">
            </div>

            <div class="form-group">
                <label for="instagram">Instagram</label>
                <input type="text" id="instagram" name="instagram" placeholder="Masukkan username Instagram">
            </div>

            <div class="form-group">
                <label for="github">GitHub</label>
                <input type="text" id="github" name="github" placeholder="Masukkan link GitHub">
            </div>

            <div class="form-group">
                <input type="submit" value="Simpan">
            </div>
        </form>
    </section>

    <div id="skillsModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <div class="form-group">
                <label for="skillName">Skill Name</label>
                <input type="text" id="skillName" placeholder="Enter skill name" class="input-field">

                <label for="skillValue" style="margin-top: 2rem">Performance (0-100)</label>
                <input type="number" id="skillValue" placeholder="Enter performance" class="input-field">
            </div>
            <button id="saveSkillBtn" class="save-skill-btn">Save Skill</button>
        </div>
    </div>

    <script src="script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loadMoreButton = document.getElementById('load-more');
            let itemsToShow = 6;
            const allItems = document.querySelectorAll('.content-portofolio');

            function showItems(count) {
                allItems.forEach((item, index) => {
                    if (index < count) {
                        item.style.opacity = '0';
                        item.style.display = 'block';
                        setTimeout(() => {
                            item.style.transition = 'opacity 0.5s ease-in-out';
                            item.style.opacity = '1';
                        }, 10);
                    } else {
                        item.style.opacity = '0';
                        setTimeout(() => {
                            item.style.display = 'none';
                        }, 500);
                    }
                });

                if (count >= allItems.length) {
                    loadMoreButton.textContent = 'Sembunyikan';
                } else {
                    loadMoreButton.textContent = 'Lihat lebih banyak';
                }
            }

            showItems(itemsToShow);

            loadMoreButton.addEventListener('click', function() {
                if (itemsToShow >= allItems.length) {
                    itemsToShow = 6;
                    showItems(itemsToShow);
                } else {
                    itemsToShow += 6;
                    showItems(itemsToShow);
                }
            });
        });
    </script>

</div>
<script src="js/script.js"></script>
</body>
</html>


<?php /**PATH C:\Users\Admin\Documents\vicky\portofolio\resources\views/admin/index.blade.php ENDPATH**/ ?>